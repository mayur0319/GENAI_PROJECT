import React from "react";
import DNAEffect from "./DNAEffect.tsx";

const Home = () => {
  return <DNAEffect />;
};

export default Home;
