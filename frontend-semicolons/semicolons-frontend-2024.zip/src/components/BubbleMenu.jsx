import React from "react";
import { BubbleMenu } from "@tiptap/react";

const BubbleMenuBar = ({ editor }) => {
  const activeButton = " text-white  m-1 px-3 py-1 rounded-lg bg-[#3F3F3F] ";
  const inActiveButton =
    " bg-black text-white px-2 py-1 m-1 border-2 border-[#3F3F3F] rounded-sm hover:bg-[#3F3F3F]";
  return (
    <BubbleMenu
      className="bg-black p-2 mx-2 rounded-md"
      editor={editor}
      tippyOptions={{ duration: 100 }}
    >
      <button
        onClick={() => {
          const { view, state } = editor;
          const { from, to } = view.state.selection;
          const text = state.doc.textBetween(from, to, "\n");
        }}
        className="h-6 px-4 w-32 rounded-sm bg-gradient-to-b from-blue-500 to-blue-600 text-white text-sm focus:ring-2 focus:ring-blue-400 hover:shadow-xl transition duration-200"
      >
        Re-generate
      </button>
    </BubbleMenu>
  );
};

export default BubbleMenuBar;
