import React from "react";
// Main TipTap Components & editor Initator
import { EditorContent, useEditor } from "@tiptap/react";
// Tiptap STraterKit
import StarterKit from "@tiptap/starter-kit";
// Document & Paragraph
import Document from "@tiptap/extension-document";
import Paragraph from "@tiptap/extension-paragraph";
// For Link Adding
import Link from "@tiptap/extension-link";
// Text Styles & Formating
import Highlight from "@tiptap/extension-highlight";
import TextAlign from "@tiptap/extension-text-align";
import ListItem from "@tiptap/extension-list-item";
import TextStyle from "@tiptap/extension-text-style";
import Underline from "@tiptap/extension-underline";
import Heading from "@tiptap/extension-heading";

import MenuBar from "./MenuBar.jsx";
import FloatingBar from "./FloatingBar"
import BubbleMenuBar from "./BubbleMenu"

const Editor = ({ content, setContent }) => {
  const editor = useEditor({
    editorProps: {
      attributes: {
        class:
          "prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none",
      },
    },
    extensions: [
      TextStyle.configure({ types: [ListItem.name] }),
      StarterKit.configure({
        bulletList: {
          keepMarks: true,
          keepAttributes: false,
        },
        orderedList: {
          keepMarks: true,
          keepAttributes: false,
        },
      }),
      TextAlign.configure({
        types: ["heading", "paragraph"],
      }),
      Highlight,
      Underline,
      Document,
      Paragraph,

      Link.configure({
        openOnClick: true,
        validate: (href) => /^https?:\/\//.test(href),
        HTMLAttributes: {
          class: "link",
        },
      }),
      Heading.configure({
        levels: [1, 2, 3],
      }),
    ],
    content: content,
    onUpdate({ editor }) {
      setContent(editor.getHTML());
    },
  });

  const data = "Hello World";

  const [isEditorVisible, setIsEditorVisible] = React.useState(false);

  const handleClick = () => {
    editor.commands.setContent(data);
    setIsEditorVisible(!false);
  };

  return (
    <div className="w-8/12 h-auto lg:flex md:flex flex-col gap-8 items-start justify-center">
    <h1> Hi eieiedkfds</h1>
    <div className=" h-20 w-full flex items-start">

    <input
      type="text"
    
      placeholder="Write topic: eg-How to improve adherence to newlifestyle for recently diagnosed type 2 diabetic patients"
      className="w-full h-full px-6 mb-3 border-[#3F3F3F] bg-[#252525] rounded-l-md focus:outline-none text-white focus:ring-blue-600 focus:ring-opacity-50"
    />
    <button
      onClick={handleClick}
      className="inline-flex h-full items-center px-10 rounded-r-md bg-gradient-to-b from-blue-500 to-blue-600 text-white focus:ring-2 focus:ring-blue-400 hover:shadow-xl transition duration-200"
    >
      <strong>Proceed</strong>
    </button>
  </div>  

      {isEditorVisible && (
        <div className="relative w-full">
          <MenuBar editor={editor} />
          <FloatingBar editor={editor}/>
          <BubbleMenuBar editor={editor}/>
          <EditorContent
            editor={editor}
            className="bg-[#252525] text-white w-full p-6 rounded-b-md focus:border"
          />
        </div>
      )}
    </div>
  );
};

export default Editor;
